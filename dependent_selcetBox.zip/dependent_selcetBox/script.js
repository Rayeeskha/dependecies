let countryArray = [{id:1,name:'India'},{id:2,name:'Pakistan'},{id:3,name:'UAE'},
					{id:4,name:'America'}];

let stateArray = [{st_id:1,st_name:'Uttar Pradesh'},{st_id:1,st_name:'Punjab'},{st_id:1,st_name:'Delhi'},
				  {st_id:2,st_name:'Blochistan'},{st_id:2,st_name:'Islama'},{st_id:2,st_name:'Punjab'},
				  {st_id:3,st_name:'Dubai'},{st_id:3,st_name:'Abu Dhabi'},{st_id:3,st_name:'Sharjah'},
				  {st_id:4,st_name:'California'},{st_id:4,st_name:'Alaska'},{st_id:4,st_name:'Florida'}];

let cityArray = [{cty_id:1,cty_name:'lucknow'},{cty_id:1,cty_name:'Noida'},{cty_id:1,cty_name:'Mubai'},
				 {cty_id:2,cty_name:'Karachi'},{cty_id:2,cty_name:'Lohare'},{cty_id:2,cty_name:'RawalPindi'},
				 {cty_id:3,cty_name:'Ajman'},{cty_id:3,cty_name:'Kalba'},{cty_id:3,cty_name:'Ruwais'},
				 {cty_id:4,cty_name:'New York'},{cty_id:4,cty_name:'Chicago'},{cty_id:4,cty_name:'Los Angeles'}];


		


let countrySelectBox = document.querySelector('#Country');
let stateSelectBox = document.querySelector('#State');
let citySelectBox = document.querySelector('#City');


let countryOption = `<option> Select Contry </option>`;
for(let country of countryArray)
{
	countryOption += `<option value="${country.id}"> ${country.name} </option>`;
}
countrySelectBox.innerHTML = countryOption;


//change Event
 countrySelectBox.addEventListener('change',function () {
	let counSelectedId = Number.parseInt(countrySelectBox.value);
	let SelectState = stateArray.filter(function(state){
		return state.st_id === counSelectedId ;

	});

		let selectCity = cityArray.filter(function(city)
		{
			return city.cty_id === counSelectedId ;


			});



	//display State

	let statOption =`<option>Select State</option>`;
	for(let state of SelectState)
	{
		statOption +=`<option>${state.st_name}</option>`
	}
	stateSelectBox.innerHTML = statOption;


	//dislay city

	let cityOption = `<option>Select City</option>`;
	for(let city of selectCity)
	{
		cityOption  +=`<option>${city.cty_name}</option>`;
	}
	citySelectBox.innerHTML = cityOption;
});			 